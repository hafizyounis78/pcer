<?php

namespace App\Http\Controllers;

use App\EmpEvalMaster;
use App\Employee;
use App\EvalSystem;
use App\Lawsuit;
use App\LawsuitSource;
use App\RateStatus;
use App\ResponsibleLawyer;
use App\Task;
use App\TaskStatus;
use App\LawsuitResult;
use Illuminate\Http\Request;
use PDF;
use App;

class ReportController extends Controller
{

}
