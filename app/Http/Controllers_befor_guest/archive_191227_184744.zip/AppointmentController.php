<?php

namespace App\Http\Controllers;

use App\Appointments;
use App\Patient;
use App\User;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        date_default_timezone_set('Asia/Gaza');

        $this->data['page_title'] = 'Appointments';
        //   $this->data['location_link'] = 'painFile/view';
        $this->data['location_title'] = 'Appointment View';
        return view(appointment_vw() . '.view')->with($this->data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getUserByDept(Request $request)
    {
        $user_type_id = $request->user_type_id;
        $users = User::where('user_type_id', $user_type_id)->get();
        $html = '<option value="">select..</option>';
        if (isset($users))
            foreach ($users as $user) {
                $html .= '<option value="' . $user->id . '">' . $user->name . '</option>';

            }
        return response()->json(['success' => true, 'html' => $html]);
    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        dd($request->all());
        $painFile_id=$request->painFile_id;
        $appointment = new Appointments();
        $appointment->pain_file_id=$painFile_id;
        $appointment->appointment_date=$request->appointment_date;
        $appointment->appointment_type=$request->appointment_type;
        $appointment->appointment_dept=$request->appointment_dept;
        $appointment->appointment_loc=$request->appointment_loc ;
        $appointment->attend_date=$request->attend_date;
        $appointment->comments=$request->comments;
        $appointment->created_by = auth()->user()->id;
        $appointment->org_id = auth()->user()->org_id;
        if($appointment->save())
            return response()->json(['success' => true]);
        return response()->json(['success' => false]);


    }
    public function get_patient_by_name(Request $request)
    {

        $query = $_GET['query'];
        $patients = Patient::with('PainFile')->select('id','name')->distinct('name')->where('org_id', auth()->user()->org_id)
            ->where('name', 'like', '%' . $query . '%')
            // ->where('national_id','=',$id)
            ->get();
       // dd($patients);
        if (count($patients) > 0) {
            foreach ($patients as $patient)
                $results[] = [
                    'id' => $patient->id,
                    'name' => $patient->name];
            // dd($data);
            return response()->json($results);
        }
        return response()->json(['success' => true, 'value' => '']);

    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
