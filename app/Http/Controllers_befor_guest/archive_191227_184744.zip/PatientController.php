<?php

namespace App\Http\Controllers;

use App\PainFile;
use App\Patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class PatientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function findPatient(Request $request)
    {
        $national_id = $request->national_id;
        $patient = Patient::where('national_id', $national_id)->first();

        $html = '';
        if (isset($patient)) {
            $painFiles = PainFile::where('patient_id', $patient->id)->get();
            $html = '';
            if (isset($painFiles))
                foreach ($painFiles as $painFile) {
                    if ($painFile->status == 17) {
                        $class = 'icon-arrow-right font-blue ';
                        $title = "Open";
                    } else {
                        $class = 'fa fa-check-circle-o font-red';
                        $title = "Closed";
                    }
                    $html .= '<tr>
                        <td class="table-status">
                            <a href="javascript:;" title="' . $title . '">
                                <i class="' . $class . '"></i>
                            </a>
                        </td>
                        <td class="table-date font-blue">
                            <a href="javascript:;">' . $painFile->start_date . '</a>
                        </td>
                        <td class="table-title">
                            <h3>
                                <a href="javascript:;">' . $patient->name . '</a>
                            </h3>

                        </td>
                        <td class="table-desc"> ' . $patient->national_id . '</td>
                        <td class="table-download">
                            <a onclick="viewPainFile(' . $painFile->id . ',' . $patient->id . ',' . $painFile->status . ')" href="#">
                                <i class="icon-doc font-green-soft"></i>
                            </a>
                        </td>
                    </tr>';
                }
            return response()->json(['success' => true, 'data' => $html]);
        }
        return response()->json(['success' => false, 'data' => '']);


    }

    public function patient_setId(Request $request)
    {
        $url = $request->url;
        // dd($url);
        session()->put('national_id', '');
        $national_id = $request->national_id;

        session()->put('national_id', $national_id);
        //   dd($id);
        return Redirect::to($url);


    }


    public function index()
    {

        /* $this->data['name']='';
         return view(patient_vw() .'.register')->with($this->data);*/
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($national_id=null)
    {
        //dd($national_id);
        // $this->data['location_link']='#';
        //  $this->data['location_title']='Pain File';
        $this->data['page_title'] = 'Patient File';
        $this->data['page_title_small'] = 'Open New File';
        $this->data['national_id'] = $national_id;

        return view(patient_vw() . '.register')->with($this->data);
    }

    public function list()
    {
        dd('hi');
        $this->data['page_title'] = 'Patient File';
        $this->data['page_title_small'] = 'Open New File';
        return view(patient_vw() . '.patientlist')->with($this->data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $national_id=$request->national_id;
        $patient=Patient::where('national_id',$national_id)->first();
        if(isset($patient))
        {
            $patient->national_id = $national_id;
            $patient->name = $request->name;
            $patient->dob = $request->dob;
            $patient->gender = $request->gender;
            if ($patient->save()) {
                $painFile=PainFile::where('patient_id',$patient->id)->where('status',17)->first();
                return response()->json(['success' => true, 'painFile_id' => $painFile->id, 'patient_id' => $patient->id, 'painFile_status' => $painFile->status,]);
            }
        }else {
            $patient = new Patient();
            $patient->national_id = $national_id;
            $patient->name = $request->name;
            $patient->dob = $request->dob;
            $patient->gender = $request->gender;
            //  $patient->mobile = $request->mobile;
            $patient->org_id = auth()->user()->org_id;
            $patient->created_by = auth()->user()->id;

            if ($patient->save()) {
                $painFile = new PainFile();
                $painFile->patient_id = $patient->id;
                $painFile->start_date = $request->start_date;
                $painFile->status = 17;
                $painFile->created_by = auth()->user()->id;
                $painFile->org_id = auth()->user()->org_id;
                if ($painFile->save())
                    return response()->json(['success' => true, 'painFile_id' => $painFile->id, 'patient_id' => $patient->id, 'painFile_status' => $painFile->status,]);
                return response()->json(['success' => false]);
            }
        }
        return response()->json(['success' => false]);

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function availabileNationalId(Request $request)
    {
        $id = $request->id;
        $count = Patient::where('national_id', '=', $id)
            //->where('org_id', '=', auth()->user()->org_id)
            ->count();
        if ($count >= 1)
            return response()->json(['success' => true]);
        else
            return response()->json(['success' => false]);
    }

    public function show($id)
    {
        /*session()->put('painFile_id', null);
        session()->put('painFile_status', null);
        session()->put('patient_id', null);*/

        $this->data['page_title'] = 'Patient List';
        //  $this->data['page_title_small'] = 'Open New File';
        return view(patient_vw() . '.patientlist')->with($this->data);
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public
    function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public
    function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public
    function destroy($id)
    {
        //
    }
}
