<?php

namespace App\Http\Controllers;

use App\BaselinePharmacistConsultation;
use App\BaselineTreatmentChoice;
use Illuminate\Http\Request;

class BaselinePharmController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function store(Request $request)
    {
        $painFile_id=$request->painFile_id;
        $baseline = BaselinePharmacistConsultation::where('pain_file_id', $painFile_id)->count();
        if ($baseline == 0) {
            $baseline = new BaselinePharmacistConsultation();
            $baseline->pain_file_id =$painFile_id;
            $baseline->visit_date = $request->visit_date_pharmacist;
            $baseline->laboratory_outside_reference = $request->laboratory_outside_reference;
            $baseline->laboratory_specify = $request->laboratory_specify;
            $baseline->interactions = $request->interactions;
            $baseline->which_interactions = $request->which_interactions;
            $baseline->other_considereations = $request->other_considereations;
            $baseline->pharmacist_message = $request->pharmacist_message;
            $baseline->created_by = auth()->user()->id;
            $baseline->org_id = auth()->user()->org_id;
            if ($baseline->save()) {
                return response()->json(['success' => true]);

            }
        } else {
            $baseline = BaselinePharmacistConsultation::where('pain_file_id', $painFile_id)->first();
            $baseline->visit_date = $request->visit_date_pharmacist;
            $baseline->laboratory_outside_reference = $request->laboratory_outside_reference;
            $baseline->laboratory_specify = $request->laboratory_specify;
            $baseline->interactions = $request->interactions;
            $baseline->which_interactions = $request->which_interactions;
            $baseline->other_considereations = $request->other_considereations;
            $baseline->pharmacist_message = $request->pharmacist_message;
            $baseline->created_by = auth()->user()->id;
            $baseline->org_id = auth()->user()->org_id;
            if ($baseline->save()) {
                return response()->json(['success' => true]);

            }
        }
        return response()->json(['success' => false]);

    }

    public function insert_treatment_choice_drugs(Request $request)
    {
        //dd($request->all());
        $painFile_id=$request->painFile_id;
        $painFile_status = $request->painFile_status;
        $mediction = new BaselineTreatmentChoice();
        $mediction->pain_file_id =$painFile_id;
        $mediction->drug_id = $request->drug_id;
        $mediction->dosage = $request->dosage;
        $mediction->org_id = auth()->user()->org_id;
        $mediction->created_by = auth()->user()->id;

        if ($mediction->save()) {
            $model = BaselineTreatmentChoice::where('pain_file_id', $painFile_id)->get();
            $doctor_html = $this->draw_treatment_choice_drugs_doctor($painFile_id,$painFile_status);
            $pharm_html = $this->draw_treatment_choice_drugs_pharm($painFile_id,$painFile_status);
            return response()->json(['success' => true, 'pharm_html' => $pharm_html, 'doctor_html' => $doctor_html]);

        }
        return response()->json(['success' => false, 'pharm_html' => '', 'doctor_html' => '']);

    }

    public function delete_treatment_choice_drugs(Request $request)
    {
        $id = $request->id;
        $painFile_id=$request->painFile_id;
        $painFile_status = $request->painFile_status;
        $model = BaselineTreatmentChoice::find($id);
        if (isset($model)) {
            $model->delete();
            $doctor_html = $this->draw_treatment_choice_drugs_doctor($painFile_id,$painFile_status);
            $pharm_html = $this->draw_treatment_choice_drugs_pharm($painFile_id,$painFile_status);
            return response()->json(['success' => true, 'pharm_html' => $pharm_html, 'doctor_html' => $doctor_html]);
        } else {
            return response()->json(['success' => false, 'pharm_html' => '', 'doctor_html' => '']);
        }

    }

    public function update_treatment_choice_drugs_dosage(Request $request)
    {
        $id = $request->id;
        $painFile_id=$request->painFile_id;
        $painFile_status = $request->painFile_status;
        $model = BaselineTreatmentChoice::find($id);
        if (isset($model)) {
            $model->dosage = $request->dosage;
            $model->save();
            $doctor_html = $this->draw_treatment_choice_drugs_doctor($painFile_id,$painFile_status);
            $pharm_html = $this->draw_treatment_choice_drugs_pharm($painFile_id,$painFile_status);
            return response()->json(['success' => true, 'pharm_html' => $pharm_html, 'doctor_html' => $doctor_html]);
        } else {
            return response()->json(['success' => false, 'pharm_html' => '', 'doctor_html' => '']);
        }

    }

    public function create()
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
