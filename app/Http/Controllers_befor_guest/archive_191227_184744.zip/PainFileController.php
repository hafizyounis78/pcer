<?php

namespace App\Http\Controllers;

use App\AcutePainService;
use App\BaselineDoctorConsultation;
use App\FollowupLast;
use App\FollowupPatient;
use App\PainFile;
use App\Patient;
use App\ShareConsultationDetail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Redirect;

class PainFileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function painFile_View($painFile_id=null,$patientid=null,$painFile_status=null)
    {
        //  dd('$patientid :'.$patientid);

        //  $painFile_id = session()->get('painFile_id');
        //  $patientid = session()->get('patient_id');
        //  $painFile_status = session()->get('painFile_status');
        //dd($painFile_id);
        // $this->data['location_link']='#';
        //  $this->data['location_title']='Pain File';
        if (!isset($painFile_id))
            return redirect()->route('home');
        $this->data['page_title'] = 'Pain File';
        $this->data['page_title_small'] = '';
        $this->data['total_acutepain_count'] = AcutePainService::where('pain_file_id', $painFile_id)->count();
        $this->data['total_baseline_count'] = BaselineDoctorConsultation::where('pain_file_id', $painFile_id)->count();
        $this->data['total_followup_count'] = FollowupPatient::where('pain_file_id', $painFile_id)->count();
        $this->data['total_lastfollowup_count'] = FollowupLast::where('pain_file_id', $painFile_id)->count();
        $this->data['consultation_data'] = $this->getConsultationRequest($painFile_id);
        // dd($this->data['total_followup_count']);
        $this->data['one_patient'] = Patient::find($patientid);
        $this->data['one_painFile'] = PainFile::find($painFile_id);
        $this->data['baseline_doctor_visit_date'] = '';
        $baselineDoctor = BaselineDoctorConsultation::where('pain_file_id', $painFile_id)->first();
        if (isset($baselineDoctor))
            $this->data['baseline_doctor_visit_date'] = $baselineDoctor->visit_date;

        $this->data['painFile_Status'] = ($painFile_status == 17) ? 'Open' : 'Closed';

        $this->data['page'] = 'Pain File';

        return view(patient_vw() . '.patientfile')->with($this->data);

    }

    public function getConsultationComments(Request $request)
    {
        $id = $request->id;

        $consultations = ShareConsultationDetail::where('share_consultations_id', $id)->get();

        $html = '';
        foreach ($consultations as $row) {
            $html .= '<li class="list-group-item bg-grey-steel">
                                                <ul class="list-inline">
                                                    <li>
                                                        <i class="fa fa-user-md font-green"></i><span class="font-grey-cascade">' . $row->user_name . '</span></li>
                                                    <li>
                                                        <i class="fa fa-calendar font-green"></i><span class="font-grey-cascade">' . Carbon::parse($row->comment_date)->format('d-m-Y') . '</span></li>
                                                </ul>
                                                <p>' . $row->comment_text . '</p>
                                            </li>';

        }
        return response()->json(['success' => true, 'html' => $html]);
    }


    public
    function painFile_setId(Request $request)
    {
        $url = $request->url;
        //dd($request->all());
        session()->put('painFile_id', '');
        session()->put('painFile_status', '');
        session()->put('patient_id', '');
        $pinfileid = $request->painFile_id;
        $painFile_status = $request->painFile_status;
        $patientid = $request->patient_id;

        session()->put('painFile_id', $pinfileid);
        session()->put('painFile_status', $painFile_status);
        session()->put('patient_id', $patientid);

        return Redirect::to($url);


    }

    public
    function search_patient_list(Request $request)
    {

        $name = $request->name;
        $national_id = $request->national_id;
        $from_date = $request->from;
        $to_date = $request->to;
        $file_status = $request->file_status;
        $gender = $request->gender;
        $start_date = $request->start_date;
        $end_date = $request->end_date;
        //dd($request->all());
        $painFiles = PainFile::with('patient')->select('pain_files.*');


        if (isset($national_id) && $national_id != null) {
            $patient_list = Patient::where('national_id', '=', $national_id)->pluck('id')->toArray();
            $painFiles = $painFiles->whereIn('patient_id', $patient_list);
        }
        if (isset($name) && $name != null) {


            $patient_list = Patient::where('name', 'like', '%' . $name . '%')->pluck('id')->toArray();
            $painFiles = $painFiles->whereIn('patient_id', $patient_list);

        }
        if (isset($file_status) && $file_status != null) {

            $painFiles = $painFiles->where('status', '=', $file_status);
        }
        if (isset($gender) && $gender != null) {

            $patient_list = Patient::where('gender', $gender)->pluck('id')->toArray();
            $painFiles = $painFiles->whereIn('patient_id', $patient_list);
        }
        if (isset($from_date) && $from_date != null) {

            $painFiles = $painFiles->whereDate('start_date', '>=', $from_date);
        }
        if (isset($to_date) && $to_date != null) {

            $painFiles = $painFiles->whereDate('start_date', '<=', $to_date);
        }
        if (isset($start_date) && $start_date != '') {

            $painFiles = $painFiles->whereDate('last_followup_date', '>=', $start_date)
                ->whereDate('last_followup_date', '<=', $end_date);

        }

        $painFiles = $painFiles->orderBy('patient_id');
        $num = 1;
        return datatables()->of($painFiles)
            ->addColumn('delChk', function ($item) {
                return '<label class="mt-checkbox mt-checkbox-single mt-checkbox-outline"> <input type="checkbox" data-id= "' . $item->id . '" id="' . $item->id . '" class="checkboxes" value="1" /><span></span></label>';
            })
            ->addColumn('num', function () use (&$num) {// user & as reference to store the privies value
                return $num++;
            })
            ->addColumn('file_status_desc', function ($model) {// as foreach ($users as $user)
                if ($model->status == 17)
                    return 'Open';
                else if ($model->status == 18)
                    return 'Close';
                else
                    return '';
            })
            ->addColumn('gender_desc', function ($model) {// as foreach ($users as $user)
                $gender_list = ['1' => 'Male', '2' => 'Female'];
                return $gender_list[$model->patient->gender];
            })
            ->addColumn('followup_date', function ($model) {// as foreach ($users as $user)

                return $model->last_followup_date;
            })
            ->addColumn('action', function ($model) {// as foreach ($users as $user)
                $html = '<div class="col-md-4" ><button type = "button" class="btn btn-icon-only red" title="Delete" onclick = "deletePainFile(' . $model->id . ')" >
                <i class="fa fa-times" ></i ></button ></div >';

                return '';
            })->addColumn('patient_name', function ($model) {// as foreach ($users as $user)
                $html = ' <a onclick="viewPainFile(' . $model->id . ',' . $model->patient_id . ',' . $model->status . ')" href="#">
                                ' . $model->patient->name . '
                            </a>';

                return $html;
            })->filterColumn('name', function ($query, $keyword) {
                $patient_list = Patient::where('name', 'like', '%' . $keyword . '%')->pluck('id')->toArray();
                $query->whereIn('patient_id', $patient_list);

            })
            ->addColumn('baseline_date', function ($model) {// as foreach ($users as $user)

                return $model->baseline_date;
            })
            ->filterColumn('national_id', function ($query, $keyword) {
                $patient_list = Patient::where('national_id', 'like', '%' . $keyword . '%')->pluck('id')->toArray();
                $query->whereIn('patient_id', $patient_list);

            })
           ->orderByNullsLast()
            ->orderColumn('last_followup_date', 'last_followup_date $1')
            ->orderColumn('baseline_date', 'last_followup_date $1')
            ->rawColumns(['action', 'delChk', 'patient_name'])
            ->toJson();

    }

    public
    function delete_painfile()
    {
        dd('delete');
    }

    public
    function delete_ckd_painfile()
    {
        dd('delete ckd');
    }

    public
    function index()
    {
        //  dd('index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public
    function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public
    function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return Response
     */
    public
    function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return Response
     */
    public
    function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public
    function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return Response
     */

    public
    function destroy($id)
    {
        //
    }
}
