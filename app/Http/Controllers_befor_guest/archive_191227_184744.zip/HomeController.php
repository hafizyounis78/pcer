<?php

namespace App\Http\Controllers;

use App\FileUpload;
use App\Lawsuit;
use App\Menu;
use App\Reminder;
use App\ResponsibleLawyer;
use App\Session;
use App\Task;
use App\TaskStatus;
use Carbon\Carbon;
use Illuminate\Http\Request;


use App\User;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

        $this->middleware('auth');


    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $this->data['sub_menu'] = 'home';
        // $this->data['task_statuses'] = TaskStatus::all();
       /* session()->put('painFile_id', '');
        session()->put('painFile_status', '');
        session()->put('patient_id', '');
*/
        if (auth()->user()->type_id==1)
            return view(admin_vw() . '.home')->with($this->data);
        else
            return view(patient_vw() . '.search')->with($this->data);

    }


}
